package com.example.fromlogin;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.fromlogin.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    /////   Declare  variables  ///////

    EditText txtUsername,txtPassword;
    Button  btnLogin,btnClose;
    TextView lblClickHere;
    TextView lblClickHereResiter;
    SQLiteDatabase db;
    String username,email,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtUsername=(EditText) findViewById(R.id.txtUserName_Login);
        txtPassword=(EditText) findViewById(R.id.txtPassword_login);
        btnClose=(Button) findViewById(R.id.btnClose_login);
        btnLogin=(Button) findViewById(R.id.btnLogin_login);

        ////////     Button Login on Form Login   /////////
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtUsername.getText().toString().equals("")){
                    txtUsername.setError("Please Enter UserName");
                    txtUsername.requestFocus();
                }else if(txtPassword.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Please Enter Password",Toast.LENGTH_LONG).show();
                }else {
                    ////  Static Code   ////////

//                    if (txtUsername.getText().toString().equals("admin")) {
//                        if (txtPassword.getText().toString().equals("123")) {
//                            finish();
//                            Toast.makeText(getApplicationContext(),"Login Successfully",Toast.LENGTH_LONG).show();
//                            Intent i=new Intent(MainActivity.this,Register.class);
//                            startActivity(i);
//                        } else {
//                            Toast.makeText(getApplicationContext(), "Password InCorrect", Toast.LENGTH_LONG).show();
//                            txtPassword.setText("");
//                            txtPassword.requestFocus();
//                        }
//                    } else {
//                        Toast.makeText(getApplicationContext(), "UserName Incorrect", Toast.LENGTH_LONG).show();
//                        txtUsername.setText("");
//                        txtUsername.requestFocus();
//                    }
                    //////   Dynamic Code   ////////

                    db = openOrCreateDatabase("POS_DB", MODE_PRIVATE, null);
                    try {
                        Cursor c = db.rawQuery("SELECT USERNAME,PASSWORD FROM USER_TBL", null);
                        c.moveToFirst();
                        do {
                            username = c.getString(c.getColumnIndex("USERNAME"));
                            password = c.getString(c.getColumnIndex("PASSWORD"));
                            if (txtUsername.getText().toString().equals(username)) {
                                if (txtPassword.getText().toString().equals(password)) {
                                    Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_LONG).show();
                                    break;
                                } else {
                                }
                            }
                        } while (c.moveToNext());

                    } catch (Exception e) {
                        Log.d("Error", e.toString());
                    }

                }
            }
        });

        ///////    Button Close on Form Login   //////////

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });

        ///////     Button Click Here On Form Login    //////////

        lblClickHere=(TextView)findViewById(R.id.lblClickHere_Login);
        lblClickHere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,Register.class);
                startActivity(i);
            }
        });



        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



}