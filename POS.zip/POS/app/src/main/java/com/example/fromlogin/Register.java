package com.example.fromlogin;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import org.w3c.dom.Text;

public class Register extends Activity {
    EditText tUserNameRegister,tEmailRegister,tPasswordRegister,tConfirmRegister;
    Button bRegister,bCloseRegister;
    TextView lClickHereRegister;
    SQLiteDatabase db;
    String  UserName,Email,Password;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        ////////////   Create Database   //////////////

        try{
            db=openOrCreateDatabase("POS_DB",MODE_PRIVATE,null);
            db.execSQL("CREATE TABLE IF NOT EXISTS USER_TBL(ID INTEGER PRIMARY KEY AUTOINCREMENT,USERNAME varchar(50),EMAIL varchar(50),PASSWORD varchar(50))");
        }catch (Exception e){
            e.printStackTrace();
        }


        tUserNameRegister=(EditText) findViewById(R.id.txtUserName_Register);
        tEmailRegister=(EditText) findViewById(R.id.txtEmail_Register);
        tPasswordRegister=(EditText) findViewById(R.id.txtPassword_Register);
        tConfirmRegister=(EditText) findViewById(R.id.txtConfirmPassword_Register);
        bRegister=(Button) findViewById(R.id.btnRegister);
        bCloseRegister=(Button) findViewById(R.id.btnClose_Register);
        lClickHereRegister=(TextView) findViewById(R.id.lblClickHere_Register);

        ///////////  Button Click Here On Form Register  /////////////

        lClickHereRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        /////////   Button Close On Form Register    /////////

        bCloseRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        //////////      Button Register On Form Register   ///////////

        bRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tUserNameRegister.getText().toString().equals("")){
                    tUserNameRegister.setError("Please Enter Your UserName");
                    tUserNameRegister.requestFocus();
                }else if(tEmailRegister.getText().toString().equals("")){
                    tEmailRegister.setError("Please Enter Your Email");
                    tEmailRegister.requestFocus();
                }else if(tPasswordRegister.getText().toString().equals("")){
                    tPasswordRegister.setError("Please Enter Password");
                    tPasswordRegister.requestFocus();
                }else if (! tConfirmRegister.getText().toString().equals(tPasswordRegister.getText().toString())){
                    tConfirmRegister.setError("Your Password does not match");
                    tConfirmRegister.requestFocus();
                }else{
                    UserName=tUserNameRegister.getText().toString();
                    Email=tEmailRegister.getText().toString();
                    Password=tPasswordRegister.getText().toString();
                    try{
                        db.execSQL("INSERT INTO USER_TBL(USERNAME,EMAIL,PASSWORD) VALUES('"+ UserName+"','"+ Email +"','"+Password+"')");
                        Toast.makeText(getApplicationContext(),"User Create Success",Toast.LENGTH_LONG).show();
                        finish();
                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                }


            }
        });



    }
}
